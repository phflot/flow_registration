The plugin uses some GUI elements from big data viewer, which also needs to be installed. 
In general, it should run out of the box with the FIJI bundle. 